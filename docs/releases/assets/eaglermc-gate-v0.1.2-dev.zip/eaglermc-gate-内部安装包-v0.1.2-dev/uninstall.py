#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""一键卸载（整机退出）：把「内部安装包」在这台机器上装过的东西逐项撤回。

对照包内「安装说明.md」的安装面，处理五项：
  [1/5] 技能副本（skill install 装入宿主目录）→ 改名归档（可逆，可随时改回）
  [2/5] 提交期钩子（core.hooksPath）          → 只对你 --unhook 点名的仓库撤回；不删文件
  [3/5] Claude Code 插件                      → plugin uninstall + marketplace remove
  [4/5] OpenClaw 扩展                         → 移出 extensions 归档（重启桌面端生效）
  [5/5] 人用 CLI（pip 包）                    → pip uninstall eaglermc-gate

用法（默认只预演，不改任何东西；确认无误后加 --yes 执行）：

    python uninstall.py                                   # 预演：列出每一项将做什么
    python uninstall.py --yes                             # 执行
    python uninstall.py --yes --unhook <端仓>              # 顺带撤回该仓库的提交期钩子（可多次）
    python uninstall.py --yes --skip openclaw,pip         # 想保留某几项时

原则：能自动做的自动做；够不着的打印现成命令；防误删（特征校验）；全程留痕（台账）。
退出码：0 = 完成 / 本来就没有可卸的；1 = 有未完成项或参数问题（见输出）。
"""
import argparse
import io
import json
import os
import shutil
import subprocess
import sys
import time

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

SKILL_NAME = "eaglermc-harness"
# 与 eaglermc_gate/cli.py 的 SKILL_PRESETS 保持一致（壳层常量镜像，别单边改）
SKILL_PRESETS = {
    "claude": os.path.join(os.path.expanduser("~"), ".claude", "skills"),
    "opencode": os.path.join(os.path.expanduser("~"), ".config", "opencode", "skills"),
    "codebuddy": os.path.join(os.path.expanduser("~"), ".codebuddy", "skills"),
}
SKIP_KEYS = ("skills", "hooks", "claude", "openclaw", "pip")
CLAUDE_PLUGIN_CMDS = (
    ["claude", "plugin", "uninstall", "eaglermc-gate@eaglermc-tools"],
    ["claude", "plugin", "marketplace", "remove", "eaglermc-tools"],
)


def norm(p):
    return os.path.abspath(p).replace(os.sep, "/")


def stamp():
    return time.strftime("%Y%m%d-%H%M%S")


def _decode(b):
    """子进程字节输出解码：UTF-8 严格失败回退 GB18030（Windows CLI 兼容）。"""
    if b is None:
        return ""
    if isinstance(b, str):
        return b
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("gb18030", "replace")


def run_cmd(args, timeout=300):
    """跑一个外部命令；返回 (rc, 合并输出)。.cmd/.bat 在 Windows 上经 cmd /c 执行。"""
    exe = shutil.which(args[0]) or args[0]
    if os.name == "nt" and exe.lower().endswith((".cmd", ".bat")):
        cmd = [os.environ.get("COMSPEC", "cmd.exe"), "/c", exe] + list(args[1:])
    else:
        cmd = [exe] + list(args[1:])
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout)
        return p.returncode, (_decode(p.stdout) + _decode(p.stderr))
    except Exception as ex:
        return 127, "无法执行 %s：%r" % (args[0], ex)


def record(a, step, result, reason=""):
    """运维台账：与 cli.py 同文件同风格（entry=uninstall）；失败提示但不阻断。"""
    p = os.environ.get("EAGLERMC_OPS_LOG") or (
        os.path.join(a.harness_norm, "reports", "ops_log.jsonl") if a.harness_norm else "")
    if not p:
        return
    try:
        d = os.path.dirname(p)
        if d:
            os.makedirs(d, exist_ok=True)
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "entry": "uninstall",
               "op": "machine_uninstall", "step": step, "result": result, "reason": reason}
        with io.open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception as ex:
        print("  [ops] 台账写入失败（不阻断）：%r" % ex)


def indented(text, pad="      "):
    return "\n".join(pad + ln for ln in text.strip().splitlines() if ln.strip())


def step_skills(a):
    """[1/5] 技能副本：优先转发 cli.py（单一实现 + 台账）；无 cli 时按同规则归档。"""
    fails = []
    targets = []
    for name, base in sorted(SKILL_PRESETS.items()):
        t = os.path.join(base, SKILL_NAME)
        if os.path.isdir(t):
            targets.append((name, t))
    for d in a.skill_dir:
        d = os.path.abspath(d)
        if os.path.basename(d) == SKILL_NAME:
            t = d
        elif os.path.isdir(os.path.join(d, SKILL_NAME)):
            t = os.path.join(d, SKILL_NAME)
        else:
            print("  · 自定义目录未见 %s/：%s（跳过）" % (SKILL_NAME, norm(d)))
            continue
        if os.path.isdir(t):
            targets.append(("custom", t))
    if not targets:
        print("  · 未发现技能副本（无需处理）")
        return fails
    for name, t in targets:
        if not a.yes:
            print("  · 技能副本[%s]：将改名归档（可逆）→ %s.disabled-<时间戳>" % (name, norm(t)))
            continue
        if a.harness_cli:
            rc, out = run_cmd([a.python, a.harness_cli, "skill", "uninstall", "--dir", t])
            print("  · 技能副本[%s]：转发 cli.py skill uninstall → rc=%s" % (name, rc))
            if out.strip():
                print(indented(out))
            if rc != 0:
                fails.append("技能副本[%s] 归档失败" % name)
        else:
            arch = "%s.disabled-%s" % (t, stamp())
            try:
                os.rename(t, arch)
                print("  · 技能副本[%s]：已归档（可逆）→ %s" % (name, norm(arch)))
                record(a, "skills", "archived", norm(arch))
            except OSError as ex:
                print("  · 技能副本[%s]：✗ 归档失败：%r" % (name, ex))
                fails.append("技能副本[%s] 归档失败" % name)
                record(a, "skills", "fail", repr(ex))
    return fails


def step_hooks(a):
    """[2/5] 提交期钩子：仅 --unhook 点名的仓库；撤回 core.hooksPath（不删文件）。"""
    fails = []
    if not a.unhook:
        print("  · 未指定仓库：如需撤回，重跑并加 --unhook <端仓>（每个仓库执行一次；不删任何文件）")
        return fails
    for repo in a.unhook:
        repo = os.path.abspath(repo)
        if not os.path.isdir(repo):
            print("  · [%s]：✗ 仓库不存在" % norm(repo))
            fails.append("--unhook 仓库不存在：%s" % norm(repo))
            continue
        if not a.yes:
            print("  · [%s]：将撤回 core.hooksPath（不删文件）" % norm(repo))
            continue
        if a.harness_cli:
            rc, out = run_cmd([a.python, a.harness_cli, "hooks", "uninstall", "--repo", repo])
            print("  · [%s]：转发 cli.py hooks uninstall → rc=%s" % (norm(repo), rc))
            if out.strip():
                print(indented(out))
            if rc != 0:
                fails.append("提交期钩子撤回失败：%s" % norm(repo))
        else:
            rc, out = run_cmd(["git", "-C", repo, "config", "--local", "--unset", "core.hooksPath"])
            if rc == 5:
                print("  · [%s]：core.hooksPath 本来就未设置（无需卸载）" % norm(repo))
            elif rc != 0:
                print("  · [%s]：✗ git config --unset 失败：%s" % (norm(repo), (out or "").strip()[:160]))
                fails.append("提交期钩子撤回失败：%s" % norm(repo))
                record(a, "hooks", "fail", (out or "").strip()[:160])
            else:
                print("  · [%s]：已撤回 core.hooksPath" % norm(repo))
                record(a, "hooks", "ok", "hooksPath cleared")
    return fails


def step_claude(a):
    """[3/5] Claude Code 插件：检测到 claude CLI 才自动；否则打印手动命令。"""
    if not shutil.which("claude"):
        print("  · 未检测到 claude CLI：若你装过 Claude Code 插件，手动执行：")
        print("      claude plugin uninstall eaglermc-gate@eaglermc-tools")
        print("      claude plugin marketplace remove eaglermc-tools")
        return []
    if not a.yes:
        for c in CLAUDE_PLUGIN_CMDS:
            print("  · 将执行：%s" % " ".join(c))
        return []
    results = []
    for c in CLAUDE_PLUGIN_CMDS:
        rc, out = run_cmd(c, timeout=180)
        tail = " ｜ ".join(ln.strip() for ln in out.strip().splitlines()[-2:] if ln.strip())
        print("  · %s → rc=%s%s" % (" ".join(c), rc, ("：" + tail[:160]) if tail else ""))
        results.append(rc == 0)
    ok = all(results)
    if not ok:
        print("      （提示：报 not installed / not found 多为本来就没装，可忽略；确有问题请手动跑上面两条）")
    record(a, "claude-plugin", "ok" if ok else "warn", "")
    return []


def step_openclaw(a):
    """[4/5] OpenClaw 扩展：移出 extensions 归档（防误删：特征校验不符则拒绝）。"""
    fails = []
    state = os.path.abspath(a.openclaw_state or os.environ.get("OPENCLAW_STATE_DIR")
                            or os.path.join(os.path.expanduser("~"), ".openclaw-autoclaw"))
    ext = os.path.join(state, "extensions", "eaglermc-gate")
    if not os.path.isdir(ext):
        print("  · %s 下未发现 eaglermc-gate 扩展（无需处理）" % norm(state))
        return fails
    markers = (os.path.join(ext, ".claude-plugin", "plugin.json"),
               os.path.join(ext, ".mcp.json"))
    if not any(os.path.isfile(m) for m in markers):
        print("  · ⚠️ 目录存在但缺少 eaglermc-gate 特征文件，拒绝自动处理（防误删同名目录）：")
        print("      %s" % norm(ext))
        print("      确认确为门禁扩展且不再需要时，请手动删除该目录。")
        fails.append("OpenClaw 扩展需人工确认：%s" % norm(ext))
        return fails
    arch = os.path.join(state, "eaglermc-gate.uninstalled-%s" % stamp())
    if not a.yes:
        print("  · 将移出归档：%s" % norm(ext))
        print("                    → %s（重启桌面端生效）" % norm(arch))
        return fails
    try:
        os.rename(ext, arch)
        print("  · 已移出归档 → %s" % norm(arch))
        print("      重启 OpenClaw 桌面端后生效；确认稳定后可删归档目录。")
        record(a, "openclaw", "archived", norm(arch))
    except OSError as ex:
        print("  · ✗ 移动失败（桌面端可能正占用）：%r" % ex)
        print("      处置：退出桌面端后重跑本脚本，或手动移动该目录。")
        fails.append("OpenClaw 扩展移动失败")
        record(a, "openclaw", "fail", repr(ex))
    return fails


def step_pip(a):
    """[5/5] 人用 CLI：pip uninstall eaglermc-gate（-y；用 --python 指定解释器）。"""
    fails = []
    rc, out = run_cmd([a.python, "-m", "pip", "show", "eaglermc-gate"])
    if rc != 0:
        print("  · pip 未见 eaglermc-gate（无需处理）")
        return fails
    if not a.yes:
        print("  · 将执行：%s -m pip uninstall -y eaglermc-gate" % a.python)
        return fails
    rc, out = run_cmd([a.python, "-m", "pip", "uninstall", "-y", "eaglermc-gate"], timeout=600)
    ok = rc == 0
    tail = " ｜ ".join(ln.strip() for ln in out.strip().splitlines()[-2:] if ln.strip())
    print("  · pip uninstall → rc=%s%s" % (rc, ("：" + tail[:160]) if tail else ""))
    if not ok:
        fails.append("pip 卸载失败（解释器：%s）" % a.python)
    record(a, "pip", "ok" if ok else "fail", a.python)
    return fails


def main(argv=None):
    ap = argparse.ArgumentParser(description="一键卸载：把「内部安装包」装过的东西逐项撤回（默认预演）")
    ap.add_argument("--harness", default=None,
                    help="你的 eaglermc_harness 仓库路径（用于转发 cli.py / 写台账；缺省读 EAGLERMC_HARNESS_DIR、HARNESS_DIR）")
    ap.add_argument("--python", default=None, help="pip 卸载用的解释器（默认：当前解释器）")
    ap.add_argument("--yes", action="store_true", help="确认执行（缺省只预演，不改任何东西）")
    ap.add_argument("--dry-run", action="store_true", help="与缺省相同的显式预演开关")
    ap.add_argument("--skip", default="", help="跳过组件：skills,hooks,claude,openclaw,pip（逗号分隔）")
    ap.add_argument("--unhook", action="append", default=[], metavar="REPO",
                    help="撤回该端仓的提交期钩子（可多次）")
    ap.add_argument("--openclaw-state", default=None, help="OpenClaw 状态目录（默认 ~/.openclaw-autoclaw）")
    ap.add_argument("--skill-dir", action="append", default=[], metavar="DIR",
                    help="额外技能目录（宿主 skills 目录或技能目录本体，可多次）")
    a = ap.parse_args(argv)
    a.python = a.python or sys.executable or "python"
    if a.dry_run:
        a.yes = False

    skip = set(x.strip() for x in (a.skip or "").split(",") if x.strip())
    unknown = skip - set(SKIP_KEYS)
    if unknown:
        print("✗ --skip 不认识这几项：%s（可选：%s）" % (",".join(sorted(unknown)), ",".join(SKIP_KEYS)))
        return 1

    harness = (a.harness or os.environ.get("EAGLERMC_HARNESS_DIR")
               or os.environ.get("HARNESS_DIR") or "").strip()
    a.harness_norm = norm(harness) if harness else ""
    a.harness_cli = ""
    if a.harness_norm:
        c = os.path.join(a.harness_norm, "eaglermc_gate", "cli.py")
        if os.path.isfile(c):
            a.harness_cli = c
        else:
            print("提示：%s 下没找到 eaglermc_gate/cli.py —— 技能/钩子将走内置同规则处理" % a.harness_norm)

    state_show = (a.openclaw_state or os.environ.get("OPENCLAW_STATE_DIR")
                  or os.path.join(os.path.expanduser("~"), ".openclaw-autoclaw"))
    print("== eaglermc-gate 一键卸载 ==================================")
    print("   模式    : %s" % ("执行（--yes）" if a.yes else "预演（不改任何东西；确认后加 --yes 执行）"))
    print("   引擎库  : %s" % (a.harness_norm or "(未指定——技能/钩子走内置处理)"))
    print("   解释器  : %s（pip 卸载目标）" % a.python)
    print("   OpenClaw: %s" % norm(state_show))
    print("")

    fails = []
    steps = (
        ("skills", "[1/5] 技能副本（skill install 装入宿主）", step_skills),
        ("hooks", "[2/5] 提交期钩子（core.hooksPath）", step_hooks),
        ("claude", "[3/5] Claude Code 插件", step_claude),
        ("openclaw", "[4/5] OpenClaw 扩展", step_openclaw),
        ("pip", "[5/5] 人用 CLI（pip 包）", step_pip),
    )
    for key, title, fn in steps:
        if key in skip:
            print("%s —— 跳过（--skip %s）" % (title, key))
            continue
        print(title)
        fails += fn(a)

    print("")
    print("── 收尾提示 ──────────────────────────────")
    print(" · 重启 OpenClaw 桌面端：让扩展卸载生效（重启后 plugins list 应查无 eaglermc-gate）。")
    print(" · 手工注册过 MCP 的客户端（claude mcp add / codex mcp add 等）：到对应宿主 mcp remove（见 RUNBOOK「4. 卸载与回滚」）。")
    print(" · 安装包目录：不再需要时整目录删除即可（含本脚本与 marketplace/）。")
    print(" · 你的引擎仓库：本工具全程未改动%s；去留由你决定。" % (("（%s）" % a.harness_norm) if a.harness_norm else ""))
    print(" · 验证查无：pip show eaglermc-gate ｜ claude plugin list ｜ OpenClaw plugins list ｜ cli.py skill status。")
    if not a.yes:
        print("")
        print("以上为预演；确认后加 --yes 执行。")
        return 0
    if fails:
        print("")
        print("⚠️ 有 %d 项未完成，请按上方提示处理后重跑本脚本：" % len(fails))
        for f in fails:
            print("   - %s" % f)
        record(a, "summary", "partial", "; ".join(fails)[:200])
        return 1
    print("")
    print("✅ 卸载完成（台账已记录）。想回来时，重新解压安装包按「安装说明」装一遍即可。")
    record(a, "summary", "done", "")
    return 0


if __name__ == "__main__":
    sys.exit(main())
