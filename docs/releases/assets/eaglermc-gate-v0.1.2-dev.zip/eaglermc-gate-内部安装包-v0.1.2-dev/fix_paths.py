#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""路径适配：把「内部安装包」里按打包机打戳的 marketplace 配置改到你自己的机器。

背景：包内 marketplace/plugins/eaglermc-gate/.mcp.json 在打包时写入了打包机的
python 解释器路径与 eaglermc_harness 引擎路径（插件机制要求绝对路径）；换机器
使用前跑一次本脚本即可完成适配（幂等，可重复执行）。

用法：

    python fix_paths.py --harness <你的 eaglermc_harness 路径>
    python fix_paths.py --mcp-json <任意 .mcp.json 路径> --harness <你的 eaglermc_harness 路径>

默认：--python = 当前解释器；--marketplace = 本脚本所在目录下的 marketplace/（包内布局）。
退出码：0 = 成功；1 = 失败（路径不存在 / 未找到配置等）。
"""
import argparse
import io
import json
import os
import sys

for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def norm(p):
    return os.path.abspath(p).replace(os.sep, "/")


def find_mcp_json(marketplace):
    cands = [
        os.path.join(marketplace, "plugins", "eaglermc-gate", ".mcp.json"),
        os.path.join(marketplace, "eaglermc-gate", ".mcp.json"),
        os.path.join(marketplace, ".mcp.json"),
    ]
    for c in cands:
        if os.path.isfile(c):
            return c
    return None


def main(argv=None):
    ap = argparse.ArgumentParser(description="把安装包内的 .mcp.json 适配到本机（python / 引擎路径）")
    ap.add_argument("--harness", default=None,
                    help="你的 eaglermc_harness 仓库路径（缺省读 EAGLERMC_HARNESS_DIR / HARNESS_DIR）")
    ap.add_argument("--python", default=None, help="python 解释器路径（默认：当前解释器）")
    ap.add_argument("--marketplace", default=None,
                    help="marketplace 目录（默认：本脚本所在目录下的 marketplace/）")
    ap.add_argument("--mcp-json", default=None,
                    help="直接指定要改写的 .mcp.json（已安装副本等特殊场景）")
    a = ap.parse_args(argv)

    harness = (a.harness or os.environ.get("EAGLERMC_HARNESS_DIR")
               or os.environ.get("HARNESS_DIR") or "").strip()
    if not harness:
        print("✗ 请用 --harness 指定 eaglermc_harness 路径（或设置 EAGLERMC_HARNESS_DIR）")
        return 1
    harness = norm(harness)
    if not os.path.isfile(os.path.join(harness, "eaglermc_gate", "mcp.py")):
        print("✗ 在 %s 下没找到 eaglermc_gate/mcp.py —— --harness 要指向你 clone 的 eaglermc_harness 仓库根" % harness)
        return 1
    mcp_py = harness + "/eaglermc_gate/mcp.py"

    python = norm(a.python or sys.executable)
    if not os.path.isfile(python):
        print("✗ python 解释器不存在：%s" % python)
        return 1

    if a.mcp_json:
        mj = os.path.abspath(a.mcp_json)
        if not os.path.isfile(mj):
            print("✗ 未找到 .mcp.json：%s" % mj)
            return 1
    else:
        marketplace = os.path.abspath(
            a.marketplace or os.path.join(os.path.dirname(os.path.abspath(__file__)), "marketplace"))
        if not os.path.isdir(marketplace):
            print("✗ marketplace 目录不存在：%s（用 --marketplace 指定）" % marketplace)
            return 1
        mj = find_mcp_json(marketplace)
        if not mj:
            print("✗ 在 %s 里没找到 plugins/eaglermc-gate/.mcp.json（用 --mcp-json 直接指定）" % marketplace)
            return 1

    try:
        data = json.loads(io.open(mj, encoding="utf-8").read())
        srv = data["mcpServers"]["eaglermc-gate"]
    except Exception as ex:
        print("✗ 无法解析 %s：%r" % (mj, ex))
        return 1

    old_cmd = srv.get("command")
    old_arg0 = (srv.get("args") or [None])[0]
    env = srv.setdefault("env", {})
    old_env = env.get("EAGLERMC_HARNESS_DIR")

    srv["command"] = python
    if srv.get("args"):
        srv["args"][0] = mcp_py
    else:
        srv["args"] = [mcp_py]
    env["EAGLERMC_HARNESS_DIR"] = harness

    io.open(mj, "w", encoding="utf-8", newline="\n").write(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n")

    print("适配文件：%s" % mj)
    print("  command                  : %s  →  %s" % (old_cmd, python))
    print("  args[0]                  : %s  →  %s" % (old_arg0, mcp_py))
    print("  env.EAGLERMC_HARNESS_DIR : %s  →  %s" % (old_env, harness))
    print("✅ 适配完成。下一步：claude plugin marketplace add <本包目录>/marketplace（OpenClaw 见 OPENCLAW.md）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
